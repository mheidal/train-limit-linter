Merge checklist:
- [ ] Incremented version
- [ ] Added to changelog
- [ ] Generated new release .zip file