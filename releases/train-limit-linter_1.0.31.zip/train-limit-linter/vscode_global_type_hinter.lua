---@meta
---@type TLLGlobal
global = {} ---@diagnostic disable-line because of missing fields