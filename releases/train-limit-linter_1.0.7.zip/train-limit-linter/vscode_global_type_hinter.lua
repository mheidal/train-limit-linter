---@diagnostic disable: missing-fields
--- This file should never be imported. This simply indicates the type of `global` to VS Code.

---@type TLLGlobal
global = {}